window.gmcServer = false
